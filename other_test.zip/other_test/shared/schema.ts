import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const testResults = pgTable("test_results", {
  id: serial("id").primaryKey(),
  testCategory: text("test_category").notNull(),
  testMethod: text("test_method").notNull(),
  status: text("status").notNull(), // 'passed', 'failed', 'warning'
  executionTime: real("execution_time").notNull(),
  coverage: real("coverage").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const testMetrics = pgTable("test_metrics", {
  id: serial("id").primaryKey(),
  totalTests: integer("total_tests").notNull(),
  passedTests: integer("passed_tests").notNull(),
  failedTests: integer("failed_tests").notNull(),
  warningTests: integer("warning_tests").notNull(),
  overallCoverage: real("overall_coverage").notNull(),
  cyclomaticComplexity: real("cyclomatic_complexity").notNull(),
  technicalDebt: real("technical_debt").notNull(),
  bugDensity: real("bug_density").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const logEvents = pgTable("log_events", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(), // 'mob_spawn', 'state_transition', 'alert_status', 'target_assignment'
  mobId: text("mob_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  details: text("details").notNull(),
  gameLevel: text("game_level").notNull(),
});

export const healthReminders = pgTable("health_reminders", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull(),
  currentHealth: integer("current_health").notNull(),
  hasPotions: boolean("has_potions").notNull(),
  reminderType: text("reminder_type").notNull(), // 'use_potion', 'missing_potion'
  reminderText: text("reminder_text").notNull(),
  displayColor: text("display_color").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTestResultSchema = createInsertSchema(testResults).omit({
  id: true,
  createdAt: true,
});

export const insertTestMetricsSchema = createInsertSchema(testMetrics).omit({
  id: true,
  updatedAt: true,
});

export const insertLogEventSchema = createInsertSchema(logEvents).omit({
  id: true,
  timestamp: true,
});

export const insertHealthReminderSchema = createInsertSchema(healthReminders).omit({
  id: true,
  timestamp: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type TestResult = typeof testResults.$inferSelect;
export type InsertTestResult = z.infer<typeof insertTestResultSchema>;
export type TestMetrics = typeof testMetrics.$inferSelect;
export type InsertTestMetrics = z.infer<typeof insertTestMetricsSchema>;
export type LogEvent = typeof logEvents.$inferSelect;
export type InsertLogEvent = z.infer<typeof insertLogEventSchema>;
export type HealthReminder = typeof healthReminders.$inferSelect;
export type InsertHealthReminder = z.infer<typeof insertHealthReminderSchema>;
