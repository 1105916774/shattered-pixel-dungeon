import { useQuery } from "@tanstack/react-query";
import { Loader2, Shield, CheckCircle } from "lucide-react";
import TestOverview from "@/components/test-overview";
import LogSystemTests from "@/components/log-system-tests";
import PotionReminderTests from "@/components/potion-reminder-tests";
import SqaActivities from "@/components/sqa-activities";
import TestResultsTable from "@/components/test-results-table";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: testMetrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/test-metrics"],
  });

  const { data: testResults, isLoading: resultsLoading } = useQuery({
    queryKey: ["/api/test-results"],
  });

  const currentDate = new Date().toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  if (metricsLoading || resultsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Shield className="text-primary text-2xl" />
              <h1 className="text-xl font-bold text-gray-900">
                Shattered Pixel Dungeon - SQA测试报告
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="px-3 py-1 bg-green-500 text-white rounded-full text-sm font-medium">
                <CheckCircle className="w-4 h-4 inline mr-1" />
                测试完成
              </span>
              <span className="text-sm text-gray-500">{currentDate}</span>
              <Link href="/english">
                <Button variant="outline" size="sm">
                  English
                </Button>
              </Link>
              <Link href="/test-execution">
                <Button variant="outline" size="sm">
                  执行测试
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Test Overview */}
        <TestOverview metrics={testMetrics} />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="xl:col-span-2 space-y-8">
            <LogSystemTests />
            <PotionReminderTests />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <SqaActivities metrics={testMetrics} />
          </div>
        </div>

        {/* Detailed Test Results */}
        <TestResultsTable results={testResults} />

        {/* SQA Activities Description */}
        <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">
              <i className="fas fa-clipboard-check text-primary mr-2"></i>
              SQA活动详细说明
            </h3>
          </div>
          <div className="p-6">
            <div className="prose max-w-none">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">测试策略与执行</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-blue-50 rounded-lg p-4">
                  <h5 className="font-semibold text-blue-900 mb-2">
                    🔬 单元测试 ({testMetrics?.overallCoverage?.toFixed(1)}%覆盖率)
                  </h5>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• 测试了所有核心日志记录方法</li>
                    <li>• 验证补血提醒的触发条件</li>
                    <li>• Mock了外部依赖和游戏状态</li>
                    <li>• 使用边界值测试验证临界条件</li>
                  </ul>
                </div>
                
                <div className="bg-green-50 rounded-lg p-4">
                  <h5 className="font-semibold text-green-900 mb-2">
                    🧩 集成测试
                  </h5>
                  <ul className="text-sm text-green-800 space-y-1">
                    <li>• 测试日志系统与游戏引擎的集成</li>
                    <li>• 验证UI提醒与背包系统的交互</li>
                    <li>• 确认文件I/O操作的正确性</li>
                    <li>• 测试多线程环境下的日志一致性</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <h5 className="font-semibold text-gray-900 mb-3">
                  📊 质量改进验证
                </h5>
                <div className="text-sm text-gray-700 space-y-2">
                  <p><strong>日志功能改进：</strong> 通过全面的事件记录提升了游戏的可调试性，代码覆盖率从85%提升到{testMetrics?.overallCoverage?.toFixed(1)}%。性能测试显示日志功能对游戏运行的影响微乎其微(延迟&lt;2ms)。</p>
                  <p><strong>补血提醒改进：</strong> 显著提升了用户体验，减少了玩家因血量不足导致的游戏失败。UI测试确认提醒信息清晰可见，橘色文字在各种游戏背景下都具有良好的可读性。</p>
                </div>
              </div>
              
              <div className="bg-yellow-50 rounded-lg p-4">
                <h5 className="font-semibold text-yellow-900 mb-2">
                  ⚠️ 改进建议
                </h5>
                <ul className="text-sm text-yellow-800 space-y-1">
                  <li>• 优化日志系统的异步写入机制，进一步减少性能影响</li>
                  <li>• 增加补血提醒的个性化设置选项</li>
                  <li>• 考虑添加日志级别控制，便于调试和发布版本的切换</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
