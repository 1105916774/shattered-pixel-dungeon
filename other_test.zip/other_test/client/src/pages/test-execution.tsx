import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Play, TestTube, Heart, FileText } from "lucide-react";
import { Link } from "wouter";

export default function TestExecution() {
  const [mobType, setMobType] = useState("Rat");
  const [gameLevel, setGameLevel] = useState("1");
  const [playerId, setPlayerId] = useState("player_001");
  const [currentHealth, setCurrentHealth] = useState(5);
  const [hasPotions, setHasPotions] = useState(true);
  const [logOutput, setLogOutput] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const executeTestsMutation = useMutation({
    mutationFn: async (category: string) => {
      const response = await apiRequest("POST", `/api/execute-tests/${category}`);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "测试执行成功",
        description: `${data.message}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/test-results"] });
      queryClient.invalidateQueries({ queryKey: ["/api/test-metrics"] });
    },
    onError: () => {
      toast({
        title: "测试执行失败",
        description: "请检查测试环境配置",
        variant: "destructive",
      });
    },
  });

  const simulateMobSpawnMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/simulate-mob-spawn", {
        mobType,
        level: gameLevel,
      });
      return response.json();
    },
    onSuccess: (data) => {
      const logEntry = `[${new Date().toISOString()}] MOB_SPAWN: ${data.mobId} - ${data.logEvent.details}\n`;
      setLogOutput(prev => prev + logEntry);
      toast({
        title: "Mob生成模拟成功",
        description: `生成了 ${mobType} (ID: ${data.mobId})`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/log-events"] });
    },
  });

  const simulateHealthReminderMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/simulate-health-reminder", {
        playerId,
        currentHealth,
        hasPotions,
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.reminder) {
        const logEntry = `[${new Date().toISOString()}] HEALTH_REMINDER: ${data.reminder.reminderText}\n`;
        setLogOutput(prev => prev + logEntry);
        toast({
          title: "补血提醒触发",
          description: data.reminder.reminderText,
        });
      } else {
        toast({
          title: "无需提醒",
          description: data.message,
        });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/health-reminders"] });
    },
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  返回报告
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-gray-900">测试执行控制台</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Test Execution Panel */}
          <div className="space-y-6">
            {/* Run Test Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TestTube className="w-5 h-5 mr-2 text-primary" />
                  执行测试套件
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={() => executeTestsMutation.mutate("日志功能")}
                  disabled={executeTestsMutation.isPending}
                  className="w-full"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  {executeTestsMutation.isPending ? "执行中..." : "执行日志功能测试"}
                </Button>
                
                <Button 
                  onClick={() => executeTestsMutation.mutate("补血提醒")}
                  disabled={executeTestsMutation.isPending}
                  className="w-full"
                  variant="outline"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  {executeTestsMutation.isPending ? "执行中..." : "执行补血提醒测试"}
                </Button>
              </CardContent>
            </Card>

            {/* Mob Spawn Simulation */}
            <Card>
              <CardHeader>
                <CardTitle>Mob生成模拟</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="mobType">Mob类型</Label>
                  <Input
                    id="mobType"
                    value={mobType}
                    onChange={(e) => setMobType(e.target.value)}
                    placeholder="输入mob类型 (如: Rat, Spider, Skeleton)"
                  />
                </div>
                
                <div>
                  <Label htmlFor="gameLevel">游戏关卡</Label>
                  <Input
                    id="gameLevel"
                    value={gameLevel}
                    onChange={(e) => setGameLevel(e.target.value)}
                    placeholder="输入关卡编号"
                  />
                </div>
                
                <Button 
                  onClick={() => simulateMobSpawnMutation.mutate()}
                  disabled={simulateMobSpawnMutation.isPending}
                  className="w-full"
                  variant="secondary"
                >
                  <Play className="w-4 h-4 mr-2" />
                  {simulateMobSpawnMutation.isPending ? "生成中..." : "模拟Mob生成"}
                </Button>
              </CardContent>
            </Card>

            {/* Health Reminder Simulation */}
            <Card>
              <CardHeader>
                <CardTitle>补血提醒模拟</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="playerId">玩家ID</Label>
                  <Input
                    id="playerId"
                    value={playerId}
                    onChange={(e) => setPlayerId(e.target.value)}
                    placeholder="输入玩家ID"
                  />
                </div>
                
                <div>
                  <Label htmlFor="currentHealth">当前血量</Label>
                  <Input
                    id="currentHealth"
                    type="number"
                    value={currentHealth}
                    onChange={(e) => setCurrentHealth(Number(e.target.value))}
                    min="0"
                    max="100"
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="hasPotions"
                    checked={hasPotions}
                    onChange={(e) => setHasPotions(e.target.checked)}
                    className="rounded"
                  />
                  <Label htmlFor="hasPotions">背包中有补血药水</Label>
                </div>
                
                <Button 
                  onClick={() => simulateHealthReminderMutation.mutate()}
                  disabled={simulateHealthReminderMutation.isPending}
                  className="w-full"
                  variant="secondary"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  {simulateHealthReminderMutation.isPending ? "检测中..." : "触发血量检测"}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Log Output */}
          <div>
            <Card className="h-full">
              <CardHeader>
                <CardTitle>实时日志输出</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={logOutput}
                  readOnly
                  className="font-mono text-sm min-h-[600px] bg-black text-green-400"
                  placeholder="日志输出将在这里显示..."
                />
                <div className="mt-4 flex justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setLogOutput("")}
                  >
                    清空日志
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      navigator.clipboard.writeText(logOutput);
                      toast({ title: "已复制到剪贴板" });
                    }}
                  >
                    复制日志
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
