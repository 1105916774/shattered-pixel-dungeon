// Mock game state for testing purposes
export interface GameState {
  player: Player;
  mobs: Mob[];
  level: GameLevel;
  inventory: Inventory;
}

export interface Player {
  id: string;
  health: number;
  maxHealth: number;
  level: number;
  position: Position;
}

export interface Mob {
  id: string;
  type: string;
  health: number;
  maxHealth: number;
  state: MobState;
  position: Position;
  target?: string;
  isAlerted: boolean;
  spawnTime: Date;
}

export interface Position {
  x: number;
  y: number;
}

export interface GameLevel {
  id: string;
  depth: number;
  name: string;
  size: { width: number; height: number };
}

export interface Inventory {
  items: Item[];
  maxSlots: number;
}

export interface Item {
  id: string;
  type: string;
  name: string;
  quantity: number;
}

export enum MobState {
  WANDERING = "WANDERING",
  HUNTING = "HUNTING",
  FLEEING = "FLEEING",
  SLEEPING = "SLEEPING",
  ATTACKING = "ATTACKING",
}

export class MockGameState {
  private state: GameState;

  constructor() {
    this.state = this.createInitialState();
  }

  private createInitialState(): GameState {
    return {
      player: {
        id: "player_001",
        health: 20,
        maxHealth: 20,
        level: 1,
        position: { x: 5, y: 5 },
      },
      mobs: [
        {
          id: "mob_001",
          type: "Rat",
          health: 8,
          maxHealth: 8,
          state: MobState.WANDERING,
          position: { x: 10, y: 8 },
          isAlerted: false,
          spawnTime: new Date(),
        },
        {
          id: "mob_002", 
          type: "Spider",
          health: 12,
          maxHealth: 12,
          state: MobState.SLEEPING,
          position: { x: 15, y: 12 },
          isAlerted: false,
          spawnTime: new Date(),
        },
      ],
      level: {
        id: "level_001",
        depth: 1,
        name: "Sewers - Level 1",
        size: { width: 20, height: 20 },
      },
      inventory: {
        items: [
          {
            id: "item_001",
            type: "healing_potion",
            name: "治疗药水",
            quantity: 2,
          },
          {
            id: "item_002",
            type: "weapon",
            name: "短剑",
            quantity: 1,
          },
        ],
        maxSlots: 10,
      },
    };
  }

  getGameState(): GameState {
    return { ...this.state };
  }

  getPlayer(): Player {
    return { ...this.state.player };
  }

  setPlayerHealth(health: number): void {
    this.state.player.health = Math.max(0, Math.min(health, this.state.player.maxHealth));
  }

  getMobs(): Mob[] {
    return [...this.state.mobs];
  }

  getMobById(id: string): Mob | undefined {
    return this.state.mobs.find(mob => mob.id === id);
  }

  spawnMob(type: string, position: Position): Mob {
    const newMob: Mob = {
      id: `mob_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      health: this.getMaxHealthForMobType(type),
      maxHealth: this.getMaxHealthForMobType(type),
      state: MobState.WANDERING,
      position: { ...position },
      isAlerted: false,
      spawnTime: new Date(),
    };
    
    this.state.mobs.push(newMob);
    return { ...newMob };
  }

  setMobState(mobId: string, newState: MobState): boolean {
    const mob = this.state.mobs.find(m => m.id === mobId);
    if (mob) {
      mob.state = newState;
      return true;
    }
    return false;
  }

  setMobTarget(mobId: string, targetId: string | undefined): boolean {
    const mob = this.state.mobs.find(m => m.id === mobId);
    if (mob) {
      mob.target = targetId;
      return true;
    }
    return false;
  }

  setMobAlerted(mobId: string, alerted: boolean): boolean {
    const mob = this.state.mobs.find(m => m.id === mobId);
    if (mob) {
      mob.isAlerted = alerted;
      return true;
    }
    return false;
  }

  hasHealingPotions(): boolean {
    return this.state.inventory.items.some(
      item => item.type === "healing_potion" && item.quantity > 0
    );
  }

  getHealingPotionCount(): number {
    const potion = this.state.inventory.items.find(item => item.type === "healing_potion");
    return potion ? potion.quantity : 0;
  }

  useHealingPotion(): boolean {
    const potion = this.state.inventory.items.find(item => item.type === "healing_potion");
    if (potion && potion.quantity > 0) {
      potion.quantity--;
      // 恢复玩家血量
      const healAmount = 10;
      this.setPlayerHealth(this.state.player.health + healAmount);
      return true;
    }
    return false;
  }

  addItem(type: string, name: string, quantity: number = 1): void {
    const existingItem = this.state.inventory.items.find(item => item.type === type);
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      this.state.inventory.items.push({
        id: `item_${Date.now()}`,
        type,
        name,
        quantity,
      });
    }
  }

  private getMaxHealthForMobType(type: string): number {
    const healthMap: Record<string, number> = {
      "Rat": 8,
      "Spider": 12,
      "Skeleton": 15,
      "Ghost": 18,
      "Crab": 10,
      "Gnoll": 20,
      "Bat": 6,
    };
    return healthMap[type] || 10;
  }

  // 用于测试的便捷方法
  simulateDamageToPlayer(damage: number): void {
    this.setPlayerHealth(this.state.player.health - damage);
  }

  simulateMobStateTransition(mobId: string, fromState: MobState, toState: MobState): boolean {
    const mob = this.getMobById(mobId);
    if (mob && mob.state === fromState) {
      return this.setMobState(mobId, toState);
    }
    return false;
  }

  simulateMobAlert(mobId: string, reason: string): boolean {
    const success = this.setMobAlerted(mobId, true);
    if (success) {
      // 可以在这里记录警报原因
      console.log(`Mob ${mobId} alerted due to: ${reason}`);
    }
    return success;
  }

  resetGameState(): void {
    this.state = this.createInitialState();
  }

  // 检查是否需要显示血量提醒
  shouldShowHealthReminder(): boolean {
    return this.state.player.health < 10;
  }

  // 获取血量提醒文本
  getHealthReminderText(): string {
    if (!this.shouldShowHealthReminder()) {
      return "";
    }

    if (this.hasHealingPotions()) {
      return "🧪 血量不足！使用背包中的补血药水恢复生命值";
    } else {
      return "⚠️ 血量危险！背包中缺少补血药水，请尽快寻找";
    }
  }

  // 获取提醒类型
  getReminderType(): "use_potion" | "missing_potion" | "none" {
    if (!this.shouldShowHealthReminder()) {
      return "none";
    }
    return this.hasHealingPotions() ? "use_potion" : "missing_potion";
  }
}

export const mockGameState = new MockGameState();
