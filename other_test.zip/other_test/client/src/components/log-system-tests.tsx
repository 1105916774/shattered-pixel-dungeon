import { FileText, CheckCircle, AlertTriangle } from "lucide-react";

export default function LogSystemTests() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">
            <FileText className="text-blue-600 w-5 h-5 inline mr-2" />
            日志功能测试结果
          </h2>
          <span className="px-3 py-1 bg-green-500 text-white rounded-full text-sm font-medium">
            25/26 通过
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="space-y-4">
          {/* Mob生成事件测试 */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">Mob生成事件日志测试</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                通过
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">验证mob生成时的时间戳和标识符记录准确性</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm overflow-x-auto">
              <div className="text-green-600">✓ 测试用例: testMobSpawnLogging()</div>
              <div className="text-gray-600 mt-1">
                • 生成5个不同类型的mob<br />
                • 验证时间戳格式正确性<br />
                • 确认mob标识符唯一性<br />
                • 检查日志文件写入成功
              </div>
            </div>
          </div>

          {/* 状态转换测试 */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">状态转换日志测试</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                通过
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">测试mob状态变化的完整记录功能</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ 测试用例: testStateTransitionLogging()</div>
              <div className="text-gray-600 mt-1">
                • WANDERING → HUNTING 状态转换<br />
                • HUNTING → FLEEING 状态转换<br />
                • 验证所有状态变化被记录
              </div>
            </div>
          </div>

          {/* 警报状态测试 */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">警报状态日志测试</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                通过
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">验证mob警报状态变化的记录功能</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ 测试用例: testAlertStatusLogging()</div>
              <div className="text-gray-600 mt-1">
                • 正常状态 → 警报状态转换<br />
                • 警报状态触发条件验证<br />
                • 警报解除记录验证
              </div>
            </div>
          </div>

          {/* 目标分配测试 */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">目标分配日志测试</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                通过
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">测试mob目标设置和变更的日志记录</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ 测试用例: testTargetAssignmentLogging()</div>
              <div className="text-gray-600 mt-1">
                • 初始目标设置记录<br />
                • 目标变更事件记录<br />
                • 目标丢失处理记录
              </div>
            </div>
          </div>

          {/* 性能测试 */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">日志性能影响测试</h3>
              <span className="px-2 py-1 bg-yellow-500 text-white rounded text-xs flex items-center">
                <AlertTriangle className="w-3 h-3 mr-1" />
                警告
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">确保日志功能不影响游戏性能</div>
            <div className="bg-yellow-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-yellow-600">⚠ 测试用例: testLoggingPerformanceImpact()</div>
              <div className="text-gray-600 mt-1">
                • 游戏帧率: 59.2 fps (目标: &gt;60 fps)<br />
                • 日志延迟: 1.2ms (可接受范围)<br />
                • 建议优化异步写入机制
              </div>
            </div>
          </div>

          {/* 日志格式测试 */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">日志格式一致性测试</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                通过
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">验证日志输出格式的清晰性和一致性</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ 测试用例: testLogFormat()</div>
              <div className="text-gray-600 mt-1">
                • 时间戳格式标准化<br />
                • 事件类型分类清晰<br />
                • 终端输出和文件一致性
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
