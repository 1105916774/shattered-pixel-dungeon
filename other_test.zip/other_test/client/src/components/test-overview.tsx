import { SquareCheck, ThumbsUp, Code, GitBranch } from "lucide-react";
import type { TestMetrics } from "@shared/schema";

interface TestOverviewProps {
  metrics?: TestMetrics;
}

export default function TestOverview({ metrics }: TestOverviewProps) {
  if (!metrics) {
    return (
      <div className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-pulse">
              <div className="flex items-center">
                <div className="p-3 bg-gray-200 rounded-lg w-12 h-12"></div>
                <div className="ml-4 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-20"></div>
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const passRate = ((metrics.passedTests / metrics.totalTests) * 100).toFixed(1);

  return (
    <div className="mb-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <SquareCheck className="text-green-600 w-6 h-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">总测试用例</p>
              <p className="text-2xl font-bold text-gray-900">{metrics.totalTests}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <ThumbsUp className="text-green-600 w-6 h-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">通过率</p>
              <p className="text-2xl font-bold text-green-600">{passRate}%</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Code className="text-blue-600 w-6 h-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">代码覆盖率</p>
              <p className="text-2xl font-bold text-blue-600">{metrics.overallCoverage.toFixed(1)}%</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <GitBranch className="text-yellow-600 w-6 h-6" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">圈复杂度</p>
              <p className="text-2xl font-bold text-yellow-600">{metrics.cyclomaticComplexity.toFixed(1)}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
