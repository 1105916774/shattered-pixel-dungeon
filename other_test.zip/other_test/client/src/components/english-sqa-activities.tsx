import { Settings, TrendingUp, Server } from "lucide-react";
import type { TestMetrics } from "@shared/schema";

interface SqaActivitiesProps {
  metrics?: TestMetrics;
}

export default function EnglishSqaActivities({ metrics }: SqaActivitiesProps) {
  if (!metrics) {
    return (
      <div className="space-y-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 animate-pulse">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="h-6 bg-gray-200 rounded w-32"></div>
            </div>
            <div className="p-6 space-y-3">
              {[1, 2, 3, 4].map((j) => (
                <div key={j} className="h-4 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* SQA Activities Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            <Settings className="text-blue-600 w-5 h-5 inline mr-2" />
            SQA Activities Overview
          </h3>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Unit Test Coverage</span>
              <span className="text-sm font-bold text-green-600">{metrics.overallCoverage.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-green-500 h-2 rounded-full transition-all duration-1000 ease-out" 
                style={{ width: `${metrics.overallCoverage}%` }}
              ></div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Integration Testing</span>
              <span className="text-sm font-bold text-green-600">Passed</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">System Testing</span>
              <span className="text-sm font-bold text-green-600">Passed</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Static Code Analysis</span>
              <span className="text-sm font-bold text-green-600">Passed</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Mock Testing</span>
              <span className="text-sm font-bold text-green-600">Passed</span>
            </div>
          </div>
        </div>
      </div>

      {/* Code Quality Metrics */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            <TrendingUp className="text-blue-600 w-5 h-5 inline mr-2" />
            Code Quality Metrics
          </h3>
        </div>
        <div className="p-6">
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Cyclomatic Complexity</span>
                <span className="px-2 py-1 bg-green-500 text-white rounded text-xs">Excellent</span>
              </div>
              <div className="text-2xl font-bold text-green-600">{metrics.cyclomaticComplexity.toFixed(1)}</div>
              <div className="text-xs text-gray-500">Target: &lt;5.0</div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Technical Debt</span>
                <span className="px-2 py-1 bg-green-500 text-white rounded text-xs">Low</span>
              </div>
              <div className="text-2xl font-bold text-green-600">{metrics.technicalDebt.toFixed(1)}h</div>
              <div className="text-xs text-gray-500">Estimated Fix Time</div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Bug Density</span>
                <span className="px-2 py-1 bg-green-500 text-white rounded text-xs">Excellent</span>
              </div>
              <div className="text-2xl font-bold text-green-600">{metrics.bugDensity.toFixed(2)}</div>
              <div className="text-xs text-gray-500">Defects per KLOC</div>
            </div>
          </div>
        </div>
      </div>

      {/* Test Environment Information */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            <Server className="text-blue-600 w-5 h-5 inline mr-2" />
            Test Environment
          </h3>
        </div>
        <div className="p-6">
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Java Version:</span>
              <span className="font-medium">OpenJDK 11.0.16</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Android SDK:</span>
              <span className="font-medium">API Level 33</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Test Framework:</span>
              <span className="font-medium">JUnit 5.8.2</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Mock Framework:</span>
              <span className="font-medium">Mockito 4.6.1</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Build Tool:</span>
              <span className="font-medium">Gradle 7.5</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}