import { Heart, CheckCircle } from "lucide-react";

export default function EnglishPotionReminderTests() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">
            <Heart className="text-red-500 w-5 h-5 inline mr-2" />
            Health Potion Reminder Feature Test Results
          </h2>
          <span className="px-3 py-1 bg-green-500 text-white rounded-full text-sm font-medium">
            21/21 Passed
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="space-y-4">
          {/* Health Threshold Detection */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">Health Threshold Detection Test</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                Passed
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">Verify reminder trigger mechanism when health falls below 10hp</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ Test Case: testHealthThresholdDetection()</div>
              <div className="text-gray-600 mt-1">
                • Test boundary values: 9hp, 10hp, 11hp<br />
                • Confirmed reminder triggers at 9hp<br />
                • Confirmed no reminder at 10hp and above
              </div>
            </div>
          </div>

          {/* Potion Available Reminder */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">Potion Available Reminder Test</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                Passed
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">Test orange reminder text when health potions are available in inventory</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ Test Case: testPotionAvailableReminder()</div>
              <div className="bg-orange-100 border border-orange-200 rounded p-2 mt-2">
                <div className="text-orange-600 font-medium">
                  🧪 Low health! Use health potions from your inventory to restore health
                </div>
              </div>
            </div>
          </div>

          {/* Missing Potion Reminder */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">Missing Potion Reminder Test</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                Passed
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">Test missing potion reminder when no health potions are in inventory</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ Test Case: testPotionMissingReminder()</div>
              <div className="bg-orange-100 border border-orange-200 rounded p-2 mt-2">
                <div className="text-orange-600 font-medium">
                  ⚠️ Dangerous health level! No health potions in inventory, find some quickly
                </div>
              </div>
            </div>
          </div>

          {/* UI Display Test */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">User Interface Display Test</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                Passed
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">Verify reminder text color, position, and duration</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ Test Case: testUIDisplayAccuracy()</div>
              <div className="text-gray-600 mt-1">
                • Text color: #f59e0b (orange) ✓<br />
                • Display position: center-top of screen ✓<br />
                • Duration: 3 seconds auto-dismiss ✓<br />
                • Font size and readability ✓
              </div>
            </div>
          </div>

          {/* Boundary Conditions */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">Boundary Conditions Test</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                Passed
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">Test reminder behavior under various boundary conditions</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ Test Case: testBoundaryConditions()</div>
              <div className="text-gray-600 mt-1">
                • Health dropping from 10hp to 9hp triggers reminder<br />
                • Health rising from 9hp to 10hp stops reminder<br />
                • Potion status changes update in real-time<br />
                • Rapid consecutive damage handling
              </div>
            </div>
          </div>

          {/* Reminder Timing */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">Reminder Timing Accuracy Test</h3>
              <span className="px-2 py-1 bg-green-500 text-white rounded text-xs flex items-center">
                <CheckCircle className="w-3 h-3 mr-1" />
                Passed
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">Verify reminder trigger timing and frequency control</div>
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
              <div className="text-green-600">✓ Test Case: testReminderTiming()</div>
              <div className="text-gray-600 mt-1">
                • Prevent repetitive reminder spam<br />
                • Timely updates when status changes<br />
                • Stop reminders when game is paused<br />
                • Independent reminders in multiplayer mode
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}