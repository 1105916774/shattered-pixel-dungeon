import { 
  users, testResults, testMetrics, logEvents, healthReminders,
  type User, type InsertUser, type TestResult, type InsertTestResult,
  type TestMetrics, type InsertTestMetrics, type LogEvent, type InsertLogEvent,
  type HealthReminder, type InsertHealthReminder
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Test Results methods
  getTestResults(): Promise<TestResult[]>;
  createTestResult(testResult: InsertTestResult): Promise<TestResult>;
  getTestResultsByCategory(category: string): Promise<TestResult[]>;
  
  // Test Metrics methods
  getLatestTestMetrics(): Promise<TestMetrics | undefined>;
  createTestMetrics(metrics: InsertTestMetrics): Promise<TestMetrics>;
  updateTestMetrics(metrics: InsertTestMetrics): Promise<TestMetrics>;
  
  // Log Events methods
  getLogEvents(): Promise<LogEvent[]>;
  createLogEvent(logEvent: InsertLogEvent): Promise<LogEvent>;
  getLogEventsByType(eventType: string): Promise<LogEvent[]>;
  getLogEventsByMobId(mobId: string): Promise<LogEvent[]>;
  
  // Health Reminders methods
  getHealthReminders(): Promise<HealthReminder[]>;
  createHealthReminder(reminder: InsertHealthReminder): Promise<HealthReminder>;
  getHealthRemindersByPlayer(playerId: string): Promise<HealthReminder[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private testResults: Map<number, TestResult>;
  private testMetrics: Map<number, TestMetrics>;
  private logEvents: Map<number, LogEvent>;
  private healthReminders: Map<number, HealthReminder>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.testResults = new Map();
    this.testMetrics = new Map();
    this.logEvents = new Map();
    this.healthReminders = new Map();
    this.currentId = 1;
    
    // Initialize with sample test data
    this.initializeTestData();
  }

  private initializeTestData() {
    // Sample test results
    const sampleTestResults: TestResult[] = [
      {
        id: this.currentId++,
        testCategory: "日志功能",
        testMethod: "testMobSpawnLogging",
        status: "passed",
        executionTime: 0.12,
        coverage: 94,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "日志功能",
        testMethod: "testStateTransitionLogging",
        status: "passed",
        executionTime: 0.08,
        coverage: 91,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "日志功能",
        testMethod: "testAlertStatusLogging",
        status: "passed",
        executionTime: 0.15,
        coverage: 89,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "日志功能",
        testMethod: "testTargetAssignmentLogging",
        status: "passed",
        executionTime: 0.10,
        coverage: 92,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "日志功能",
        testMethod: "testLoggingPerformanceImpact",
        status: "warning",
        executionTime: 2.34,
        coverage: 89,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "补血提醒",
        testMethod: "testHealthThresholdDetection",
        status: "passed",
        executionTime: 0.05,
        coverage: 96,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "补血提醒",
        testMethod: "testPotionAvailableReminder",
        status: "passed",
        executionTime: 0.03,
        coverage: 98,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "补血提醒",
        testMethod: "testPotionMissingReminder",
        status: "passed",
        executionTime: 0.04,
        coverage: 97,
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        testCategory: "补血提醒",
        testMethod: "testUIDisplayAccuracy",
        status: "passed",
        executionTime: 0.07,
        coverage: 95,
        createdAt: new Date(),
      },
    ];

    sampleTestResults.forEach(result => {
      this.testResults.set(result.id, result);
    });

    // Sample test metrics
    const sampleMetrics: TestMetrics = {
      id: this.currentId++,
      totalTests: 47,
      passedTests: 45,
      failedTests: 0,
      warningTests: 2,
      overallCoverage: 92.3,
      cyclomaticComplexity: 3.2,
      technicalDebt: 0.8,
      bugDensity: 0.02,
      updatedAt: new Date(),
    };

    this.testMetrics.set(sampleMetrics.id, sampleMetrics);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getTestResults(): Promise<TestResult[]> {
    return Array.from(this.testResults.values());
  }

  async createTestResult(testResult: InsertTestResult): Promise<TestResult> {
    const id = this.currentId++;
    const result: TestResult = { 
      ...testResult, 
      id, 
      createdAt: new Date()
    };
    this.testResults.set(id, result);
    return result;
  }

  async getTestResultsByCategory(category: string): Promise<TestResult[]> {
    return Array.from(this.testResults.values()).filter(
      result => result.testCategory === category
    );
  }

  async getLatestTestMetrics(): Promise<TestMetrics | undefined> {
    const metrics = Array.from(this.testMetrics.values());
    return metrics.length > 0 ? metrics[metrics.length - 1] : undefined;
  }

  async createTestMetrics(metrics: InsertTestMetrics): Promise<TestMetrics> {
    const id = this.currentId++;
    const testMetrics: TestMetrics = { 
      ...metrics, 
      id, 
      updatedAt: new Date()
    };
    this.testMetrics.set(id, testMetrics);
    return testMetrics;
  }

  async updateTestMetrics(metrics: InsertTestMetrics): Promise<TestMetrics> {
    const existing = await this.getLatestTestMetrics();
    if (existing) {
      const updated: TestMetrics = {
        ...existing,
        ...metrics,
        updatedAt: new Date()
      };
      this.testMetrics.set(existing.id, updated);
      return updated;
    }
    return this.createTestMetrics(metrics);
  }

  async getLogEvents(): Promise<LogEvent[]> {
    return Array.from(this.logEvents.values());
  }

  async createLogEvent(logEvent: InsertLogEvent): Promise<LogEvent> {
    const id = this.currentId++;
    const event: LogEvent = { 
      ...logEvent, 
      id, 
      timestamp: new Date()
    };
    this.logEvents.set(id, event);
    return event;
  }

  async getLogEventsByType(eventType: string): Promise<LogEvent[]> {
    return Array.from(this.logEvents.values()).filter(
      event => event.eventType === eventType
    );
  }

  async getLogEventsByMobId(mobId: string): Promise<LogEvent[]> {
    return Array.from(this.logEvents.values()).filter(
      event => event.mobId === mobId
    );
  }

  async getHealthReminders(): Promise<HealthReminder[]> {
    return Array.from(this.healthReminders.values());
  }

  async createHealthReminder(reminder: InsertHealthReminder): Promise<HealthReminder> {
    const id = this.currentId++;
    const healthReminder: HealthReminder = { 
      ...reminder, 
      id, 
      timestamp: new Date()
    };
    this.healthReminders.set(id, healthReminder);
    return healthReminder;
  }

  async getHealthRemindersByPlayer(playerId: string): Promise<HealthReminder[]> {
    return Array.from(this.healthReminders.values()).filter(
      reminder => reminder.playerId === playerId
    );
  }
}

export const storage = new MemStorage();
