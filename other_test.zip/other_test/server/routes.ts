import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertTestResultSchema, insertTestMetricsSchema, 
  insertLogEventSchema, insertHealthReminderSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Test Results endpoints
  app.get("/api/test-results", async (req, res) => {
    try {
      const results = await storage.getTestResults();
      res.json(results);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch test results" });
    }
  });

  app.get("/api/test-results/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const results = await storage.getTestResultsByCategory(category);
      res.json(results);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch test results by category" });
    }
  });

  app.post("/api/test-results", async (req, res) => {
    try {
      const validatedData = insertTestResultSchema.parse(req.body);
      const result = await storage.createTestResult(validatedData);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid test result data" });
    }
  });

  // Test Metrics endpoints
  app.get("/api/test-metrics", async (req, res) => {
    try {
      const metrics = await storage.getLatestTestMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch test metrics" });
    }
  });

  app.post("/api/test-metrics", async (req, res) => {
    try {
      const validatedData = insertTestMetricsSchema.parse(req.body);
      const metrics = await storage.createTestMetrics(validatedData);
      res.json(metrics);
    } catch (error) {
      res.status(400).json({ error: "Invalid test metrics data" });
    }
  });

  app.put("/api/test-metrics", async (req, res) => {
    try {
      const validatedData = insertTestMetricsSchema.parse(req.body);
      const metrics = await storage.updateTestMetrics(validatedData);
      res.json(metrics);
    } catch (error) {
      res.status(400).json({ error: "Invalid test metrics data" });
    }
  });

  // Log Events endpoints
  app.get("/api/log-events", async (req, res) => {
    try {
      const events = await storage.getLogEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch log events" });
    }
  });

  app.get("/api/log-events/type/:eventType", async (req, res) => {
    try {
      const { eventType } = req.params;
      const events = await storage.getLogEventsByType(eventType);
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch log events by type" });
    }
  });

  app.get("/api/log-events/mob/:mobId", async (req, res) => {
    try {
      const { mobId } = req.params;
      const events = await storage.getLogEventsByMobId(mobId);
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch log events by mob ID" });
    }
  });

  app.post("/api/log-events", async (req, res) => {
    try {
      const validatedData = insertLogEventSchema.parse(req.body);
      const event = await storage.createLogEvent(validatedData);
      res.json(event);
    } catch (error) {
      res.status(400).json({ error: "Invalid log event data" });
    }
  });

  // Health Reminders endpoints
  app.get("/api/health-reminders", async (req, res) => {
    try {
      const reminders = await storage.getHealthReminders();
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch health reminders" });
    }
  });

  app.get("/api/health-reminders/player/:playerId", async (req, res) => {
    try {
      const { playerId } = req.params;
      const reminders = await storage.getHealthRemindersByPlayer(playerId);
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch health reminders by player" });
    }
  });

  app.post("/api/health-reminders", async (req, res) => {
    try {
      const validatedData = insertHealthReminderSchema.parse(req.body);
      const reminder = await storage.createHealthReminder(validatedData);
      res.json(reminder);
    } catch (error) {
      res.status(400).json({ error: "Invalid health reminder data" });
    }
  });

  // Test execution endpoints
  app.post("/api/execute-tests/:category", async (req, res) => {
    try {
      const { category } = req.params;
      
      // This would execute actual tests in a real implementation
      // For now, we'll simulate test execution
      const testResults = await executeTestCategory(category);
      
      // Store the results
      for (const result of testResults) {
        await storage.createTestResult(result);
      }
      
      res.json({ 
        message: `Tests executed for category: ${category}`,
        results: testResults
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to execute tests" });
    }
  });

  // Simulate mob spawn for logging tests
  app.post("/api/simulate-mob-spawn", async (req, res) => {
    try {
      const { mobType, level } = req.body;
      const mobId = `mob_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const logEvent = await storage.createLogEvent({
        eventType: "mob_spawn",
        mobId,
        details: `Spawned ${mobType} mob in level ${level}`,
        gameLevel: level,
      });
      
      res.json({
        message: "Mob spawn simulated successfully",
        mobId,
        logEvent
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to simulate mob spawn" });
    }
  });

  // Simulate health reminder trigger
  app.post("/api/simulate-health-reminder", async (req, res) => {
    try {
      const { playerId, currentHealth, hasPotions } = req.body;
      
      if (currentHealth >= 10) {
        return res.json({ message: "Health above threshold, no reminder needed" });
      }
      
      const reminderType = hasPotions ? "use_potion" : "missing_potion";
      const reminderText = hasPotions 
        ? "🧪 血量不足！使用背包中的补血药水恢复生命值"
        : "⚠️ 血量危险！背包中缺少补血药水，请尽快寻找";
      
      const reminder = await storage.createHealthReminder({
        playerId,
        currentHealth,
        hasPotions,
        reminderType,
        reminderText,
        displayColor: "#f59e0b",
      });
      
      res.json({
        message: "Health reminder triggered",
        reminder
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to simulate health reminder" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function executeTestCategory(category: string) {
  // Simulate test execution with realistic results
  const testMethods = {
    "日志功能": [
      "testMobSpawnLogging",
      "testStateTransitionLogging", 
      "testAlertStatusLogging",
      "testTargetAssignmentLogging",
      "testLogFileFormat",
      "testLogPerformanceImpact"
    ],
    "补血提醒": [
      "testHealthThresholdDetection",
      "testPotionAvailableReminder",
      "testPotionMissingReminder", 
      "testUIDisplayAccuracy",
      "testReminderTiming",
      "testBoundaryConditions"
    ]
  };

  const methods = testMethods[category as keyof typeof testMethods] || [];
  
  return methods.map(method => ({
    testCategory: category,
    testMethod: method,
    status: Math.random() > 0.1 ? "passed" : (Math.random() > 0.5 ? "warning" : "failed"),
    executionTime: Math.random() * 2 + 0.01,
    coverage: Math.random() * 20 + 80,
  }));
}
